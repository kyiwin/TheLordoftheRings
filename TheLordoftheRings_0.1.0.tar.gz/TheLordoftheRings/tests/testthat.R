library(testthat)
library(TheLordoftheRings)

test_check("TheLordoftheRings")
